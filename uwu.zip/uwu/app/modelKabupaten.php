<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class modelKabupaten extends Model
{
    protected $tables = "model_kabupaten";
}
