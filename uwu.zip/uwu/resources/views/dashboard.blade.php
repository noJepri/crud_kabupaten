@extends('template')
@section('konten')
    <div class="col-xs-12">
        <div class="card">
            <div class="header">
                <h2>Dashboard</h2>
            </div>
            <div class="body">
<h2 align="center">Selamat Datang Goshujin-sama !</h2>
            </div>
        </div>
    </div>
@stop